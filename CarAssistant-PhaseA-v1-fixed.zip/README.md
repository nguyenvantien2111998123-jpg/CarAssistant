# Car Assistant — Phase A v1

Minimal Android Auto media test.

Goal:
1. Build a debug APK.
2. Install it on an Android 12 phone.
3. Connect the phone to the Honda BR-V using Android Auto.
4. Verify that Car Assistant is discoverable as a media app.
5. Verify the media session/library path and a test media item.

Not included in Phase A: voice commands, opening other apps, AI, navigation, contacts/calling, and video on the car display.

The test media is a remote sample URL and is only for verifying the playback path.
